####  Licor43
##
NextJS Application for hosting an event, quiz...

## Getting Started

```
npm install
npm run dev
```

### Prerequisites

node

## Deployment
