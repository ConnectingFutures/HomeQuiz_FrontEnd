import React from "react";
import PropTypes from "prop-types";
import Wrapper from "../components/wrapper/Wrapper";
import Page from "../components/layout/Page";
import Button from "../components/button/Button";
import { withTranslation } from "../i18n";

import "../styles/components/text-block.scss";
import "../styles/components/tac.scss";

const TermsAndConditions = ({ t }) => {
  return (
    <Page title="Terms and Conditions" headerType="quiz-no-menu">
      <div className="container">
        <Wrapper className="tac-wrap" size={80}>
          <div className="text-block" style={{ marginBottom: 20 }}>
            <h2 className="title-big">{t("title")}</h2>
          </div>
          <div className="text-block__text" style={{ marginBottom: 30 }}>
            {t("content")
              .split("\n")
              .map((item, i) => (
                <span key={i}>
                  {item}
                  <br />
                </span>
              ))}
          </div>
          <div className="tac__btn-wrap">
            <Button component="link" href="/auth/register" className="btn">
              {t("go-back")}
            </Button>
          </div>
        </Wrapper>
      </div>
    </Page>
  );
};

TermsAndConditions.getInitialProps = () => ({
  namespacesRequired: ["terms-and-conditions"]
});

TermsAndConditions.propTypes = {
  t: PropTypes.func.isRequired
};

export default withTranslation("terms-and-conditions")(TermsAndConditions);
