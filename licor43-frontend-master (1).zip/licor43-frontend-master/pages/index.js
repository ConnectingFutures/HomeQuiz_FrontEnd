import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { useRouter } from 'next/router';
import Page from '../components/layout/Page';
import Wrapper from '../components/wrapper/Wrapper';
import Button from '../components/button/Button';
import { setLanguage } from '../actions/languageActions';
import { i18n, withTranslation } from '../i18n';

import flagUk from '../static/img/flag-uk.png';
import flagSpain from '../static/img/flag-spain.png';

import '../styles/components/home.scss';

const Home = ({ auth: { isAuthenticated }, setLanguage }) => {
  const router = useRouter();
  useEffect(() => {
    if (isAuthenticated) router.push('/quiz/rules');
  }, []);
  return (
    <Page title='Home' headerType='welcome'>
      <Wrapper size={120}>
        <div className='welcome-layout-home'>
          <div className='welcome-layout__text-wrapper'>
            <h1 className='color-yellow'>Play with your friends Remotely.</h1>
            <h1 className='color-white'>Juega con tus amigos Remotamente. </h1>
            <h2 className='color-yellow'>
              Sign In. Share your code with friends.
              <span>(Everyone can join. No need to download)</span>
            </h2>
            <h2 className='color-yellow'>Choose your category.</h2>
            <h2 className='color-yellow'>
              Try your most creative answer.
              <span>(No right or wrong answers)</span>
            </h2>
            <h2 className='color-yellow'>
              Get the votes to become the winner.
            </h2>
            <h2 className='color-white'>
              Regístrate. Comparte tu código con amigos.
              <span>(Todos pueden unirse. No necesita descarga)</span>
            </h2>
            <h2 className='color-white'>Elige una categoría.</h2>
            <h2 className='color-white'>
              Intenta tu respuesta más creativa.
              <span>(No hay respuestas correctas o incorrectas)</span>
            </h2>
            <h2 className='color-white'>Consigue los votos y sé el ganador.</h2>
          </div>
        </div>
        <div className='footer'>
          <span>Choose your langauge to continue</span>
          <div className='button-wrap'>
            <Button
              component='link'
              href='/auth'
              onClick={() => {
                i18n.changeLanguage('es');
                setLanguage('spanish');
              }}
            >
              <img src={flagSpain} alt='spain' />
            </Button>
            <Button
              component='link'
              href='/auth'
              onClick={() => {
                i18n.changeLanguage('en');
                setLanguage('english');
              }}
            >
              <img src={flagUk} alt='uk' />
            </Button>
          </div>
        </div>
      </Wrapper>
    </Page>
  );
};

const mapStateToProps = state => ({
  auth: state.auth
});

Home.getInitialProps = async () => ({
  namespacesRequired: ['common']
});

Home.propTypes = {
  auth: PropTypes.object.isRequired,
  setLanguage: PropTypes.func.isRequired
};

export default withTranslation('common')(
  connect(mapStateToProps, { setLanguage })(Home)
);
